#ifndef I2C_SLAVE_H__
#define I2C_SLAVE_H__
// implements a basic I2C slave

void i2c_slave_setup(unsigned char addr); // set up the slave at the given address

#endif
