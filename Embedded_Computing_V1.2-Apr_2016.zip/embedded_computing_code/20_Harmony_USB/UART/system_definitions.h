#ifndef SYSTEM_DEFINITIONS_H
#define SYSTEM_DEFINITIONS_H

#include "driver/usart/drv_usart.h"  // only one header file needed

#endif
