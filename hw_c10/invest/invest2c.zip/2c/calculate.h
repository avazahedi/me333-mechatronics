#ifndef CALCULATE__H__
#define CALCULATE__H__
#include "nu32dip.h"
#include "io.h"

void calculateGrowth(Investment *invp);

#endif