#ifndef ULTRA__H__
#define ULTRA__H__

void initultra();
unsigned int readultra();

#endif // ULTRA__H__